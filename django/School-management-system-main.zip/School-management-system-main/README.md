# School Management System

A Django-based school management system with separate workflows for administrators, teachers, and students.

## Features

- Admin, teacher, and student login flows
- Teacher and student registration with approval status
- Student fee records
- Class-based attendance tracking
- Notice management
- Contact form email configuration

## Tech Stack

- Python
- Django 3.0.5
- SQLite
- HTML templates and static assets

## Setup

1. Create and activate a virtual environment:

   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

2. Install dependencies:

   ```powershell
   pip install -r requirements.txt
   ```

3. Create database migrations and apply them:

   ```powershell
   python manage.py makemigrations
   python manage.py migrate
   ```

4. Create an admin account:

   ```powershell
   python manage.py createsuperuser
   ```

5. Run the development server:

   ```powershell
   python manage.py runserver
   ```

6. Open the app in your browser:

   ```text
   http://127.0.0.1:8000/
   ```

## Email Configuration

The contact form settings are in `schoolmanagement/settings.py`. Update these values before using email features:

- `EMAIL_HOST_USER`
- `EMAIL_HOST_PASSWORD`
- `EMAIL_RECEIVING_USER`

For production, keep email credentials and the Django secret key in environment variables instead of committing them to the repository.


