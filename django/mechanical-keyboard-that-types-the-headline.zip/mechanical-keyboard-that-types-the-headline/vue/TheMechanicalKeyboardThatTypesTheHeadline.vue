<!--
  "The mechanical keyboard that types the headline" from Animorio · https://animorio.com
  License: free on your own sites and your clients’ sites, paid work included.
  Not for resale, redistribution, templates or code collections · https://animorio.com/en/license/
-->
<script setup>
/* The mechanical keyboard that types the headline, as a Vue 3 component. Made by Animorio from the demo's own code.
   npm install gsap @fontsource-variable/mona-sans
   A few lookups still use document: with two copies of this component on one page, scope them to the container. */

import { ref, onMounted, onBeforeUnmount } from 'vue';
import gsap from 'gsap';
import '@fontsource-variable/mona-sans/wdth.css';

const container = ref(null);
let ctx;

onMounted(() => {
  ctx = gsap.context(() => {
    const cleanups = [];
    const addPageListener = (target, ...args) => { target.addEventListener(...args); cleanups.push(() => target.removeEventListener(...args)); };

    /* ---- valori da cambiare ---- */
    const HEADLINES = "Type like you mean it.|Every press, felt.|Built to be heard."; /* i titoli che la tastiera scrive uno dopo l'altro, separati da | */
    const TYPE_SPEED = 9; /* quante lettere al secondo scrive il pilota */
    const HOLD = 1.6; /* i secondi in cui il titolo finito resta fermo prima di cancellarsi */
    const DELETE_SPEED = 26; /* quante lettere al secondo cancella il tasto delete */
    const TRAVEL = 0.8; /* quanto scende un tasto premuto, rispetto alla sua altezza */
    const TILT = 38; /* l'inclinazione della tastiera all'indietro, in gradi */
    const ACCENT = "#ff5a36"; /* il colore del cursore, del bagliore sotto i tasti e dei tasti esc e return */

    (() => {
      const ridotto = matchMedia("(prefers-reduced-motion: reduce)").matches;
      const touch = matchMedia("(hover: none)").matches;
      const $ = (s) => document.querySelector(s);
      const hero = $("[data-hero]");
      const board = $("[data-board]");
      const plate = $("[data-plate]");
      const text = $("[data-text]");
      const caret = $("[data-caret]");
      const hint = $("[data-hint]");

      const LINES = HEADLINES.split("|").map((l) => l.trim()).filter(Boolean);
      document.documentElement.style.setProperty("--accento", ACCENT);
      board.style.transform = "rotateX(" + TILT + "deg)";
      if (touch) hint.textContent = "Tap the keys";

      /* the layout of a compact board, in units: [id, label, width, kind] */
      const ROWS = [
        [["esc", "esc", 1, "accent"], ["q"], ["w"], ["e"], ["r"], ["t"], ["y"], ["u"], ["i"], ["o"], ["p"], ["bksp", "delete", 2, "mod"]],
        [["tab", "tab", 1.5, "mod"], ["a"], ["s"], ["d"], ["f"], ["g"], ["h"], ["j"], ["k"], ["l"], ["'", "'"], ["enter", "return", 1.5, "accent"]],
        [["shift", "shift", 2, "mod"], ["z"], ["x"], ["c"], ["v"], ["b"], ["n"], ["m"], [",", ","], [".", "."], ["rshift", "shift", 2, "mod"]],
        [["fn", "fn", 1.25, "mod"], ["opt", "opt", 1.25, "mod"], ["cmd", "cmd", 1.5, "mod"], [" ", "", 4.5, "space"], ["rcmd", "cmd", 1.5, "mod"], ["left", "", 1, "mod"], ["down", "", 1, "mod"], ["right", "", 1, "mod"]]
      ];
      const WIDTH = 13;
      const CHEVRON = {
        left: '<svg viewBox="0 0 12 12" width="38%" aria-hidden="true"><path d="M7.4 3 4.4 6l3 3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        down: '<svg viewBox="0 0 12 12" width="38%" aria-hidden="true"><path d="M3 4.6 6 7.6l3-3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        right: '<svg viewBox="0 0 12 12" width="38%" aria-hidden="true"><path d="M4.6 3l3 3-3 3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
      };

      const keys = {};
      ROWS.forEach((row, r) => {
        let x = 0;
        row.forEach(([id, label, w = 1, kind]) => {
          const el = document.createElement("div");
          el.className = "key" + (kind ? " key--" + kind : "");
          el.dataset.x = x;
          el.dataset.y = r;
          el.dataset.w = w;
          const glow = document.createElement("span");
          glow.className = "key__glow";
          const cap = document.createElement("span");
          cap.className = "key__cap";
          if (CHEVRON[id]) cap.innerHTML = CHEVRON[id];
          else cap.textContent = label === undefined ? id.toUpperCase() : label;
          el.append(glow, cap);
          plate.appendChild(el);
          keys[id] = { el, glow, id };
          x += w;
        });
      });

      function layout() {
        const avail = Math.min(hero.clientWidth * 0.98, innerHeight * 1.08, 720);
        const u = Math.max(14, avail / (WIDTH + 0.64));
        hero.style.setProperty("--u", u + "px");
        plate.style.width = WIDTH * u + "px";
        plate.style.height = ROWS.length * u + "px";
        Object.values(keys).forEach(({ el }) => {
          el.style.left = el.dataset.x * u + "px";
          el.style.top = el.dataset.y * u + "px";
          el.style.width = el.dataset.w * u + "px";
          el.style.height = u + "px";
        });
      }
      layout();
      addPageListener(window, "resize", layout);

      /* one press: the cap travels down fast, comes back on a spring, and a glow blooms underneath */
      function press(id, hold = 0.04) {
        const k = keys[id];
        if (!k) return;
        if (ridotto) {
          gsap.fromTo(k.glow, { opacity: 0.6 }, { opacity: 0, duration: 0.5, overwrite: true });
          return;
        }
        gsap.to(k.el, { "--p": TRAVEL / 0.8, duration: 0.045, ease: "power2.out", overwrite: true });
        gsap.to(k.el, { "--p": 0, duration: 0.42, ease: "elastic.out(1, 0.45)", delay: 0.045 + hold });
        gsap.fromTo(k.glow, { opacity: 0.95 }, { opacity: 0, duration: 0.6, ease: "power2.out", delay: 0.03, overwrite: true });
      }

      /* the headline: one span per letter, so each one can land on its own */
      let blink;
      function caretSolid() {
        if (blink) blink.kill();
        gsap.set(caret, { opacity: 1 });
        if (!ridotto) blink = gsap.to(caret, { opacity: 0, duration: 0.5, ease: "steps(1)", repeat: -1, yoyo: true, delay: 0.6 });
      }
      function addChar(ch) {
        const s = document.createElement("span");
        s.className = "c";
        s.textContent = ch;
        text.appendChild(s);
        if (!ridotto) gsap.from(s, { y: "0.16em", opacity: 0, duration: 0.2, ease: "power2.out" });
        caretSolid();
      }
      function removeChar() {
        const last = text.lastElementChild;
        if (last) last.remove();
        caretSolid();
      }
      function keyFor(ch) {
        if (ch === " ") return " ";
        const low = ch.toLowerCase();
        return keys[low] ? low : null;
      }
      function typeChar(ch) {
        const id = keyFor(ch);
        if (!id) return;
        if (ch !== ch.toLowerCase()) press("shift", 0.1);
        press(id);
        addChar(ch);
      }

      /* the pilot: a seeded rhythm so every run looks like the same hand */
      let seed = 7;
      const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
      const pilot = gsap.timeline({ repeat: -1, paused: true });
      let t = 0.6;
      LINES.forEach((line) => {
        [...line].forEach((ch) => {
          pilot.call(typeChar, [ch], t);
          const base = 1 / TYPE_SPEED;
          t += ch === " " ? base * 1.5 : base * (0.7 + rnd() * 0.6);
        });
        t += HOLD;
        [...line].forEach(() => {
          pilot.call(() => { press("bksp", 0.02); removeChar(); }, null, t);
          t += 1 / DELETE_SPEED;
        });
        t += 0.35;
      });
      pilot.set({}, {}, t);

      if (ridotto) {
        [...LINES[0]].forEach(addChar);
      } else {
        caretSolid();
        pilot.play();
      }

      /* hands: a real keyboard or a tap on the keys takes over, the pilot comes back after a quiet moment */
      let idle;
      function takeOver() {
        pilot.pause();
        if (!hero.dataset.mine) {
          hero.dataset.mine = "1";
          text.textContent = "";
        }
        if (idle) idle.kill();
        idle = gsap.delayedCall(8, () => {
          delete hero.dataset.mine;
          text.textContent = "";
          if (!ridotto) pilot.restart();
          else [...LINES[0]].forEach(addChar);
        });
      }
      function handle(id) {
        takeOver();
        if (id === "bksp") { press("bksp"); removeChar(); return; }
        if (id === "enter" || id === "esc") { press(id); text.textContent = ""; caretSolid(); return; }
        if (id === " " || (id.length === 1)) {
          if (text.children.length >= 26) { press(id); return; }
          typeChar(id === " " ? " " : id);
          return;
        }
        press(id);
      }
      addPageListener(window, "keydown", (e) => {
        if (e.metaKey || e.ctrlKey || e.altKey) return;
        let id = null;
        if (e.key === "Backspace") id = "bksp";
        else if (e.key === "Enter") id = "enter";
        else if (e.key === "Escape") id = "esc";
        else if (e.key === "Tab") { id = "tab"; e.preventDefault(); }
        else if (e.key === "Shift") id = e.location === 2 ? "rshift" : "shift";
        else if (e.key === "ArrowLeft") id = "left";
        else if (e.key === "ArrowRight") id = "right";
        else if (e.key === "ArrowDown") id = "down";
        else if (e.key.length === 1) {
          if (keyFor(e.key)) {
            takeOver();
            if (text.children.length < 26) typeChar(e.key);
            else press(keyFor(e.key));
            if (e.key === " ") e.preventDefault();
            return;
          }
        }
        if (id) handle(id);
      });
      Object.values(keys).forEach(({ el, id }) => {
        el.addEventListener("pointerdown", (e) => { e.preventDefault(); handle(id); });
        if (!touch && !ridotto) {
          el.addEventListener("pointerenter", () => gsap.to(el, { "--h": 1, duration: 0.22, ease: "power2.out" }));
          el.addEventListener("pointerleave", () => gsap.to(el, { "--h": 0, duration: 0.5, ease: "elastic.out(1, 0.5)" }));
        }
      });
    })();

    return () => {
      cleanups.forEach((undo) => undo());
    };
  }, container.value);
});

onBeforeUnmount(() => ctx.revert());
</script>

<template>
  <div ref="container" style="display: contents">
    <main class="stage">
      <section class="hero" data-hero aria-label="Keymoor, mechanical keyboards">
        <p class="hero__brand"><svg viewBox="0 0 20 20" aria-hidden="true"><rect x="2.5" y="5.5" width="15" height="9" rx="2.4"></rect><path d="M6 8.6h1.6M9.2 8.6h1.6M12.4 8.6h1.6M7.2 11.4h5.6"></path></svg><span>Keymoor</span></p>
        <h1 class="hero__title" aria-live="polite"><span class="hero__text" data-text></span><span class="hero__caret" data-caret aria-hidden="true"></span></h1>
        <p class="hero__sub" data-sub>Hot-swappable 65% boards, switches lubed by hand.</p>
        <div class="hero__cta">
          <a class="hero__btn" href="#" data-btn>Shop keyboards</a>
          <span class="hero__note">Ships in 48h</span>
        </div>
        <div class="desk" data-desk>
          <div class="board" data-board aria-hidden="true">
            <div class="board__plate" data-plate></div>
          </div>
          <div class="board__shadow" aria-hidden="true"></div>
        </div>
        <p class="hero__hint" data-hint>Type anything</p>
      </section>
    </main>
  </div>
</template>

<!-- not scoped: the script builds part of the markup itself, and those elements would miss Vue's scoped attribute -->
<style>
:root {
  --fondo: #f4f3f1;
  --inchiostro: #17171a;
  --grigio: #77767c;
  --cassa: #dcdbe0;
  --cassa-scura: #c4c3ca;
  --tasto: #fbfbfa;
  --tasto-lato: #cfced4;
  --modifica: #e6e5ea;
  --modifica-lato: #bdbcc4;
  --accento: #ff5a36;
  --accento-lato: #c93a1c;
  --u: 40px;
}

* { box-sizing: border-box; }

html, body {
  margin: 0;
  height: 100%;
  background: var(--fondo);
  color: var(--inchiostro);
  font-family: "Mona Sans Variable", system-ui, sans-serif;
  -webkit-font-smoothing: antialiased;
}

.stage {
  min-height: 100vh;
  display: grid;
  place-items: center;
  overflow: hidden;
  padding: min(4vh, 28px) 16px;
}

.hero {
  width: min(100%, 760px);
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.hero__brand {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  margin: 0 0 min(1.6vh, 12px);
  padding: 5px 11px 5px 8px;
  border: 1px solid rgba(23, 23, 26, 0.09);
  border-radius: 999px;
  background: #fff;
  font-size: clamp(11px, 1.7vh, 13px);
  font-weight: 560;
  letter-spacing: 0.01em;
}
.hero__brand svg { width: 16px; height: 16px; fill: none; stroke: var(--inchiostro); stroke-width: 1.4; stroke-linecap: round; }

.hero__title {
  margin: 0;
  min-height: 1.1em;
  font-size: clamp(24px, min(7.4vw, 7.6vh), 60px);
  font-weight: 640;
  font-stretch: 96%;
  letter-spacing: -0.035em;
  line-height: 1.08;
  white-space: nowrap;
}
.hero__text .c { display: inline-block; white-space: pre; }
.hero__caret {
  display: inline-block;
  width: 0.07em;
  height: 0.86em;
  margin-left: 0.04em;
  border-radius: 1px;
  background: var(--accento);
  vertical-align: -0.08em;
}

.hero__sub {
  margin: min(1.2vh, 10px) 0 0;
  max-width: 30em;
  color: var(--grigio);
  font-size: clamp(12px, min(3.2vw, 2.1vh), 16px);
  line-height: 1.4;
}

.hero__cta {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: min(2vh, 16px);
}
.hero__btn {
  display: inline-block;
  padding: 0.7em 1.15em;
  border-radius: 999px;
  background: var(--inchiostro);
  color: #fff;
  font-size: clamp(12px, 1.9vh, 14px);
  font-weight: 600;
  text-decoration: none;
  box-shadow: 0 6px 16px -8px rgba(23, 23, 26, 0.5);
}
.hero__note { color: var(--grigio); font-size: clamp(11px, 1.7vh, 13px); }

/* the keyboard: a plate tilted back in perspective; every key is placed by the script in units */
.desk {
  position: relative;
  margin-top: min(3.4vh, 30px);
  perspective: 900px;
  perspective-origin: 50% 10%;
}
.board {
  position: relative;
  padding: calc(var(--u) * 0.32);
  border-radius: calc(var(--u) * 0.42);
  background: linear-gradient(180deg, #e6e5ea 0%, var(--cassa) 55%, var(--cassa-scura) 100%);
  box-shadow:
    0 calc(var(--u) * 0.22) 0 #b3b2ba,
    inset 0 1px 0 rgba(255, 255, 255, 0.85);
  transform: rotateX(38deg);
  transform-origin: 50% 100%;
}
.board__plate {
  position: relative;
  border-radius: calc(var(--u) * 0.18);
  background: #c9c8cf;
  box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.18);
}
.board__shadow {
  position: absolute;
  left: 6%;
  right: 6%;
  bottom: calc(var(--u) * -0.5);
  height: calc(var(--u) * 0.9);
  border-radius: 50%;
  background: radial-gradient(closest-side, rgba(23, 23, 26, 0.26), rgba(23, 23, 26, 0));
  filter: blur(6px);
  z-index: -1;
}

.key {
  position: absolute;
  --p: 0;
  --h: 0;
  --d: calc(var(--u) * 0.17);
}
.key__glow {
  position: absolute;
  inset: -22% -14%;
  border-radius: calc(var(--u) * 0.3);
  background: radial-gradient(closest-side, var(--accento), rgba(255, 90, 54, 0.35) 55%, rgba(255, 90, 54, 0));
  opacity: 0;
  filter: blur(calc(var(--u) * 0.12));
}
.key__cap {
  position: absolute;
  inset: calc(var(--u) * 0.04);
  display: flex;
  align-items: flex-start;
  justify-content: flex-start;
  padding: calc(var(--u) * 0.13) calc(var(--u) * 0.16);
  border-radius: calc(var(--u) * 0.15);
  background: linear-gradient(180deg, #ffffff 0%, var(--tasto) 60%, #f1f0ee 100%);
  color: #4c4b52;
  font-size: calc(var(--u) * 0.27);
  font-weight: 560;
  line-height: 1;
  transform: translateY(calc((var(--p) * 0.8 - var(--h) * 0.14) * var(--d)));
  box-shadow:
    0 calc((1 - var(--p) * 0.8 + var(--h) * 0.14) * var(--d)) 0 var(--tasto-lato),
    0 calc((1 - var(--p) * 0.6) * var(--d) + 2px) calc(var(--u) * 0.12) rgba(23, 23, 26, 0.16),
    inset 0 1px 0 #fff;
}
.key--mod .key__cap {
  background: linear-gradient(180deg, #efeef2 0%, var(--modifica) 70%, #dedde3 100%);
  color: #6b6a71;
  font-size: calc(var(--u) * 0.22);
  box-shadow:
    0 calc((1 - var(--p) * 0.8 + var(--h) * 0.14) * var(--d)) 0 var(--modifica-lato),
    0 calc((1 - var(--p) * 0.6) * var(--d) + 2px) calc(var(--u) * 0.12) rgba(23, 23, 26, 0.16),
    inset 0 1px 0 rgba(255, 255, 255, 0.9);
}
.key--accent .key__cap {
  background: linear-gradient(180deg, #ff7a5a 0%, var(--accento) 70%, #f04d2a 100%);
  color: #fff;
  box-shadow:
    0 calc((1 - var(--p) * 0.8 + var(--h) * 0.14) * var(--d)) 0 var(--accento-lato),
    0 calc((1 - var(--p) * 0.6) * var(--d) + 2px) calc(var(--u) * 0.12) rgba(201, 58, 28, 0.25),
    inset 0 1px 0 rgba(255, 255, 255, 0.45);
}
.key--space .key__cap { justify-content: center; align-items: center; }

.hero__hint {
  margin: calc(var(--u) * 0.8) 0 0;
  color: var(--grigio);
  font-size: clamp(10px, 1.6vh, 12px);
  letter-spacing: 0.02em;
}

@media (max-width: 520px) {
  .hero__note { display: none; }
}
</style>
