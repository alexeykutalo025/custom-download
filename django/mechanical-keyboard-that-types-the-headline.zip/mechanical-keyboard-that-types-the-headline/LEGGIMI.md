# La tastiera meccanica che scrive il titolo

Su un fondo grigio caldo chiarissimo, in alto c’è la pillola bianca del marchio Keymoor con la sua piccola tastiera disegnata, poi il titolo grande, una riga in grigio, il pulsante nero «Shop keyboards» e «Ships in 48h». Sotto, una tastiera compatta al 65 per cento, con la cassa grigia e i tasti bianchi, inclinata all’indietro in prospettiva come se stesse sulla scrivania; esc e return sono arancio. Il titolo si scrive da solo, una lettera alla volta, con il ritmo irregolare di una mano vera: a ogni lettera il suo tasto scende con la corsa vera, il lato si accorcia e l’ombra si stringe, poi torna su con una molla, e sotto il tasto si accende per un attimo un bagliore arancio. Per le maiuscole si abbassa anche shift. Ogni lettera arriva nel titolo salendo di un capello, e dopo l’ultima lettera il cursore arancio lampeggia. Il titolo resta fermo, poi delete lo cancella in fretta e arriva il successivo: «Type like you mean it.», «Every press, felt.», «Built to be heard.». Col puntatore sopra, ogni tasto si alza di poco e torna giù con un elastico; scrivendo con la tastiera vera o toccando i tasti il titolo diventa il tuo, e dopo otto secondi di calma riparte il giro.

## Come si usa

Apri index.html in un browser. Le librerie arrivano da jsDelivr: in produzione puoi scaricarle e servirle dal tuo dominio.

## Come funziona

- **Una tastiera fatta di div.** La disposizione è un elenco di righe in unità di tasto (13 di larghezza): lo script crea un div per tasto, lo posiziona in pixel calcolati dalla larghezza e dall’altezza della finestra e lo rifà al resize. Tutta la piastra sta in un elemento inclinato con rotateX dentro un contenitore con la prospettiva.
- **La corsa con due variabili.** Ogni tasto ha due variabili CSS, --p per la pressione e --h per il passaggio: il CSS le usa per spostare il copritasto e per accorciare il lato fatto di box-shadow, così GSAP anima solo due numeri e non tocca mai il transform del CSS.
- **La molla e il bagliore.** Premere vuol dire portare --p a 1 in 45 millesimi con power2.out e riportarlo a 0 con elastic.out(1, 0.45); insieme un alone radiale arancio sotto il tasto si accende e si spegne in sei decimi.
- **Il ritmo di una mano.** Il pilota è una timeline che si ripete con una chiamata per lettera: l’intervallo fra le lettere varia con un generatore a seme fisso, gli spazi sono un poco più lunghi, e ogni giro è uguale al precedente, così anteprima e video coincidono.
- **Le tue mani.** Un keydown sulla pagina o un tocco su un tasto fermano il pilota e il titolo diventa quello che scrivi, con delete, return ed esc che fanno il loro lavoro; dopo otto secondi senza tasti il pilota riparte da capo.

## Valori da cambiare

- `HEADLINES` (script.js, di partenza 'Type like you mean it.|Every press, felt.|Built to be heard.'): I titoli che la tastiera scrive uno dopo l’altro, separati da |.
- `TYPE_SPEED` (script.js, di partenza 9): Quante lettere al secondo scrive il pilota.
- `HOLD` (script.js, di partenza 1.6): I secondi in cui il titolo finito resta fermo prima di cancellarsi.
- `DELETE_SPEED` (script.js, di partenza 26): Quante lettere al secondo cancella il tasto delete.
- `TRAVEL` (script.js, di partenza 0.8): Quanto scende un tasto premuto, rispetto alla sua altezza.
- `TILT` (script.js, di partenza 38): L’inclinazione della tastiera all’indietro, in gradi.
- `ACCENT` (script.js, di partenza '#ff5a36'): Il colore del cursore, del bagliore sotto i tasti e dei tasti esc e return.

## Trappole

- Il copritasto si sposta con calc sulle variabili --p e --h dentro il CSS: GSAP anima le variabili sull’elemento del tasto e non il transform, che cancellerebbe quello della classe.
- Le misure in pixel della piastra e dei tasti si ricalcolano al resize, perché la finestra della demo cambia altezza mentre la si guarda.
- Le frecce sui tasti sono SVG disegnati: i caratteri delle frecce su iPhone possono diventare emoji.
- Il ritmo del pilota usa un generatore a seme fisso e non Math.random, così il video dell’anteprima e il giro dal vivo sono uguali.

---

# The mechanical keyboard that types the headline

On a very light warm grey background, at the top is the white pill of the Keymoor brand with its small drawn keyboard, then the big headline, a line in grey, the black «Shop keyboards» button and «Ships in 48h». Below, a compact 65 per cent keyboard, with a grey case and white keys, tilted back in perspective as if it sat on the desk; esc and return are orange. The headline types itself, one letter at a time, with the uneven rhythm of a real hand: for each letter its key goes down with real travel, its side shortens and its shadow tightens, then it springs back up, and under the key an orange glow lights up for a moment. For capitals, shift goes down too. Each letter arrives in the headline rising by a hair, and after the last one the orange cursor blinks. The headline holds, then delete wipes it quickly and the next one arrives: «Type like you mean it.», «Every press, felt.», «Built to be heard.». With the pointer over it, every key lifts a little and drops back on an elastic; typing on your real keyboard or tapping the keys makes the headline yours, and after eight quiet seconds the loop starts again.

## How to use it

Open index.html in a browser. Libraries load from jsDelivr: in production you can download them and serve them from your own domain.

## How it works

- **A keyboard made of divs.** The layout is a list of rows in key units (13 wide): the script makes one div per key, places it in pixels worked out from the width and height of the window and redoes it on resize. The whole plate lives in an element tilted with rotateX inside a container with perspective.
- **Travel with two variables.** Each key has two CSS variables, --p for the press and --h for hover: the CSS uses them to move the keycap and to shorten the side made of box-shadow, so GSAP only animates two numbers and never touches the CSS transform.
- **The spring and the glow.** Pressing means taking --p to 1 in 45 milliseconds with power2.out and bringing it back to 0 with elastic.out(1, 0.45); at the same time a radial orange halo under the key lights up and fades in six tenths.
- **The rhythm of a hand.** The pilot is a repeating timeline with one call per letter: the gap between letters varies with a fixed-seed generator, spaces are a little longer, and every loop matches the previous one, so preview and video agree.
- **Your hands.** A keydown on the page or a tap on a key stops the pilot and the headline becomes what you type, with delete, return and esc doing their job; after eight seconds without keys the pilot starts over.

## Values to change

- `HEADLINES` (script.js, default 'Type like you mean it.|Every press, felt.|Built to be heard.'): The headlines the keyboard types one after another, separated by |.
- `TYPE_SPEED` (script.js, default 9): How many letters per second the pilot types.
- `HOLD` (script.js, default 1.6): The seconds the finished headline holds before it is deleted.
- `DELETE_SPEED` (script.js, default 26): How many letters per second the delete key removes.
- `TRAVEL` (script.js, default 0.8): How far a pressed key goes down, relative to its height.
- `TILT` (script.js, default 38): How far the keyboard tilts back, in degrees.
- `ACCENT` (script.js, default '#ff5a36'): The colour of the cursor, the glow under the keys and the esc and return keys.

## Pitfalls

- The keycap moves with calc on the --p and --h variables inside the CSS: GSAP animates the variables on the key element and not the transform, which would wipe the class transform.
- The pixel sizes of the plate and the keys are recomputed on resize, because the demo window changes height while you watch it.
- The arrows on the keys are drawn SVG: arrow characters can turn into emoji on iPhone.
- The pilot’s rhythm uses a fixed-seed generator and not Math.random, so the preview video and the live loop are the same.

Animorio, 2026