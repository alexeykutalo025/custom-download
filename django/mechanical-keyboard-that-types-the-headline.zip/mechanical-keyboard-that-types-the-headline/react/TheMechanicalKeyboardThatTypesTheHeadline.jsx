/*
  "The mechanical keyboard that types the headline" from Animorio · https://animorio.com
  License: free on your own sites and your clients’ sites, paid work included.
  Not for resale, redistribution, templates or code collections · https://animorio.com/en/license/
*/
/* The mechanical keyboard that types the headline, as a React component. Made by Animorio from the demo's own code.
   npm install gsap @gsap/react @fontsource-variable/mona-sans
   The CSS is the style.css tab: save it next to this file as TheMechanicalKeyboardThatTypesTheHeadline.css.
   A few lookups still use document: with two copies of this component on one page, scope them to the container. */

import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import '@fontsource-variable/mona-sans/wdth.css';
import './TheMechanicalKeyboardThatTypesTheHeadline.css';

gsap.registerPlugin(useGSAP);

export default function TheMechanicalKeyboardThatTypesTheHeadline() {
  const container = useRef(null);

  useGSAP(() => {
    const initialMarkup = container.current.innerHTML;
    const cleanups = [];
    const addPageListener = (target, ...args) => { target.addEventListener(...args); cleanups.push(() => target.removeEventListener(...args)); };

    /* ---- valori da cambiare ---- */
    const HEADLINES = "Type like you mean it.|Every press, felt.|Built to be heard."; /* i titoli che la tastiera scrive uno dopo l'altro, separati da | */
    const TYPE_SPEED = 9; /* quante lettere al secondo scrive il pilota */
    const HOLD = 1.6; /* i secondi in cui il titolo finito resta fermo prima di cancellarsi */
    const DELETE_SPEED = 26; /* quante lettere al secondo cancella il tasto delete */
    const TRAVEL = 0.8; /* quanto scende un tasto premuto, rispetto alla sua altezza */
    const TILT = 38; /* l'inclinazione della tastiera all'indietro, in gradi */
    const ACCENT = "#ff5a36"; /* il colore del cursore, del bagliore sotto i tasti e dei tasti esc e return */

    (() => {
      const ridotto = matchMedia("(prefers-reduced-motion: reduce)").matches;
      const touch = matchMedia("(hover: none)").matches;
      const $ = (s) => document.querySelector(s);
      const hero = $("[data-hero]");
      const board = $("[data-board]");
      const plate = $("[data-plate]");
      const text = $("[data-text]");
      const caret = $("[data-caret]");
      const hint = $("[data-hint]");

      const LINES = HEADLINES.split("|").map((l) => l.trim()).filter(Boolean);
      document.documentElement.style.setProperty("--accento", ACCENT);
      board.style.transform = "rotateX(" + TILT + "deg)";
      if (touch) hint.textContent = "Tap the keys";

      /* the layout of a compact board, in units: [id, label, width, kind] */
      const ROWS = [
        [["esc", "esc", 1, "accent"], ["q"], ["w"], ["e"], ["r"], ["t"], ["y"], ["u"], ["i"], ["o"], ["p"], ["bksp", "delete", 2, "mod"]],
        [["tab", "tab", 1.5, "mod"], ["a"], ["s"], ["d"], ["f"], ["g"], ["h"], ["j"], ["k"], ["l"], ["'", "'"], ["enter", "return", 1.5, "accent"]],
        [["shift", "shift", 2, "mod"], ["z"], ["x"], ["c"], ["v"], ["b"], ["n"], ["m"], [",", ","], [".", "."], ["rshift", "shift", 2, "mod"]],
        [["fn", "fn", 1.25, "mod"], ["opt", "opt", 1.25, "mod"], ["cmd", "cmd", 1.5, "mod"], [" ", "", 4.5, "space"], ["rcmd", "cmd", 1.5, "mod"], ["left", "", 1, "mod"], ["down", "", 1, "mod"], ["right", "", 1, "mod"]]
      ];
      const WIDTH = 13;
      const CHEVRON = {
        left: '<svg viewBox="0 0 12 12" width="38%" aria-hidden="true"><path d="M7.4 3 4.4 6l3 3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        down: '<svg viewBox="0 0 12 12" width="38%" aria-hidden="true"><path d="M3 4.6 6 7.6l3-3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        right: '<svg viewBox="0 0 12 12" width="38%" aria-hidden="true"><path d="M4.6 3l3 3-3 3" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
      };

      const keys = {};
      ROWS.forEach((row, r) => {
        let x = 0;
        row.forEach(([id, label, w = 1, kind]) => {
          const el = document.createElement("div");
          el.className = "key" + (kind ? " key--" + kind : "");
          el.dataset.x = x;
          el.dataset.y = r;
          el.dataset.w = w;
          const glow = document.createElement("span");
          glow.className = "key__glow";
          const cap = document.createElement("span");
          cap.className = "key__cap";
          if (CHEVRON[id]) cap.innerHTML = CHEVRON[id];
          else cap.textContent = label === undefined ? id.toUpperCase() : label;
          el.append(glow, cap);
          plate.appendChild(el);
          keys[id] = { el, glow, id };
          x += w;
        });
      });

      function layout() {
        const avail = Math.min(hero.clientWidth * 0.98, innerHeight * 1.08, 720);
        const u = Math.max(14, avail / (WIDTH + 0.64));
        hero.style.setProperty("--u", u + "px");
        plate.style.width = WIDTH * u + "px";
        plate.style.height = ROWS.length * u + "px";
        Object.values(keys).forEach(({ el }) => {
          el.style.left = el.dataset.x * u + "px";
          el.style.top = el.dataset.y * u + "px";
          el.style.width = el.dataset.w * u + "px";
          el.style.height = u + "px";
        });
      }
      layout();
      addPageListener(window, "resize", layout);

      /* one press: the cap travels down fast, comes back on a spring, and a glow blooms underneath */
      function press(id, hold = 0.04) {
        const k = keys[id];
        if (!k) return;
        if (ridotto) {
          gsap.fromTo(k.glow, { opacity: 0.6 }, { opacity: 0, duration: 0.5, overwrite: true });
          return;
        }
        gsap.to(k.el, { "--p": TRAVEL / 0.8, duration: 0.045, ease: "power2.out", overwrite: true });
        gsap.to(k.el, { "--p": 0, duration: 0.42, ease: "elastic.out(1, 0.45)", delay: 0.045 + hold });
        gsap.fromTo(k.glow, { opacity: 0.95 }, { opacity: 0, duration: 0.6, ease: "power2.out", delay: 0.03, overwrite: true });
      }

      /* the headline: one span per letter, so each one can land on its own */
      let blink;
      function caretSolid() {
        if (blink) blink.kill();
        gsap.set(caret, { opacity: 1 });
        if (!ridotto) blink = gsap.to(caret, { opacity: 0, duration: 0.5, ease: "steps(1)", repeat: -1, yoyo: true, delay: 0.6 });
      }
      function addChar(ch) {
        const s = document.createElement("span");
        s.className = "c";
        s.textContent = ch;
        text.appendChild(s);
        if (!ridotto) gsap.from(s, { y: "0.16em", opacity: 0, duration: 0.2, ease: "power2.out" });
        caretSolid();
      }
      function removeChar() {
        const last = text.lastElementChild;
        if (last) last.remove();
        caretSolid();
      }
      function keyFor(ch) {
        if (ch === " ") return " ";
        const low = ch.toLowerCase();
        return keys[low] ? low : null;
      }
      function typeChar(ch) {
        const id = keyFor(ch);
        if (!id) return;
        if (ch !== ch.toLowerCase()) press("shift", 0.1);
        press(id);
        addChar(ch);
      }

      /* the pilot: a seeded rhythm so every run looks like the same hand */
      let seed = 7;
      const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
      const pilot = gsap.timeline({ repeat: -1, paused: true });
      let t = 0.6;
      LINES.forEach((line) => {
        [...line].forEach((ch) => {
          pilot.call(typeChar, [ch], t);
          const base = 1 / TYPE_SPEED;
          t += ch === " " ? base * 1.5 : base * (0.7 + rnd() * 0.6);
        });
        t += HOLD;
        [...line].forEach(() => {
          pilot.call(() => { press("bksp", 0.02); removeChar(); }, null, t);
          t += 1 / DELETE_SPEED;
        });
        t += 0.35;
      });
      pilot.set({}, {}, t);

      if (ridotto) {
        [...LINES[0]].forEach(addChar);
      } else {
        caretSolid();
        pilot.play();
      }

      /* hands: a real keyboard or a tap on the keys takes over, the pilot comes back after a quiet moment */
      let idle;
      function takeOver() {
        pilot.pause();
        if (!hero.dataset.mine) {
          hero.dataset.mine = "1";
          text.textContent = "";
        }
        if (idle) idle.kill();
        idle = gsap.delayedCall(8, () => {
          delete hero.dataset.mine;
          text.textContent = "";
          if (!ridotto) pilot.restart();
          else [...LINES[0]].forEach(addChar);
        });
      }
      function handle(id) {
        takeOver();
        if (id === "bksp") { press("bksp"); removeChar(); return; }
        if (id === "enter" || id === "esc") { press(id); text.textContent = ""; caretSolid(); return; }
        if (id === " " || (id.length === 1)) {
          if (text.children.length >= 26) { press(id); return; }
          typeChar(id === " " ? " " : id);
          return;
        }
        press(id);
      }
      addPageListener(window, "keydown", (e) => {
        if (e.metaKey || e.ctrlKey || e.altKey) return;
        let id = null;
        if (e.key === "Backspace") id = "bksp";
        else if (e.key === "Enter") id = "enter";
        else if (e.key === "Escape") id = "esc";
        else if (e.key === "Tab") { id = "tab"; e.preventDefault(); }
        else if (e.key === "Shift") id = e.location === 2 ? "rshift" : "shift";
        else if (e.key === "ArrowLeft") id = "left";
        else if (e.key === "ArrowRight") id = "right";
        else if (e.key === "ArrowDown") id = "down";
        else if (e.key.length === 1) {
          if (keyFor(e.key)) {
            takeOver();
            if (text.children.length < 26) typeChar(e.key);
            else press(keyFor(e.key));
            if (e.key === " ") e.preventDefault();
            return;
          }
        }
        if (id) handle(id);
      });
      Object.values(keys).forEach(({ el, id }) => {
        el.addEventListener("pointerdown", (e) => { e.preventDefault(); handle(id); });
        if (!touch && !ridotto) {
          el.addEventListener("pointerenter", () => gsap.to(el, { "--h": 1, duration: 0.22, ease: "power2.out" }));
          el.addEventListener("pointerleave", () => gsap.to(el, { "--h": 0, duration: 0.5, ease: "elastic.out(1, 0.5)" }));
        }
      });
    })();

    return () => {
      cleanups.forEach((undo) => undo());
      container.current.innerHTML = initialMarkup;
    };
  }, { scope: container });

  return (
    <div ref={container} style={{ display: 'contents' }}>
      <main className="stage">
        <section className="hero" data-hero="" aria-label="Keymoor, mechanical keyboards">
          <p className="hero__brand">
            <svg viewBox="0 0 20 20" aria-hidden="true">
              <rect x="2.5" y="5.5" width="15" height="9" rx="2.4" />
              <path d="M6 8.6h1.6M9.2 8.6h1.6M12.4 8.6h1.6M7.2 11.4h5.6" />
            </svg>
            <span>Keymoor</span>
          </p>
          <h1 className="hero__title" aria-live="polite">
            <span className="hero__text" data-text="" />
            <span className="hero__caret" data-caret="" aria-hidden="true" />
          </h1>
          <p className="hero__sub" data-sub="">Hot-swappable 65% boards, switches lubed by hand.</p>
          <div className="hero__cta">
            <a className="hero__btn" href="#" data-btn="">Shop keyboards</a>
            {' '}
            <span className="hero__note">Ships in 48h</span>
          </div>
          <div className="desk" data-desk="">
            <div className="board" data-board="" aria-hidden="true">
              <div className="board__plate" data-plate="" />
            </div>
            <div className="board__shadow" aria-hidden="true" />
          </div>
          <p className="hero__hint" data-hint="">Type anything</p>
        </section>
      </main>
    </div>
  );
}
