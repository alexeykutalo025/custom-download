<!--
  "The paper calendar" from Animorio · https://animorio.com
  License: free on your own sites and your clients’ sites, paid work included.
  Not for resale, redistribution, templates or code collections · https://animorio.com/en/license/
-->
<script setup>
/* The paper calendar, as a Vue 3 component. Made by Animorio from the demo's own code.
   npm install gsap @fontsource-variable/fraunces */

import { ref, onMounted, onBeforeUnmount } from 'vue';
import gsap from 'gsap';
import '@fontsource-variable/fraunces/opsz.css';
import '@fontsource-variable/fraunces/opsz-italic.css';

const container = ref(null);
let ctx;

onMounted(() => {
  ctx = gsap.context(() => {
    const cleanups = [];
    const addPageListener = (target, ...args) => { target.addEventListener(...args); cleanups.push(() => target.removeEventListener(...args)); };

    /* The paper calendar
       A wall calendar on a black page: a cream sheet for each month hanging from a wire binding, with the edges of the
       sheets below peeking out. The arrow down turns the page: the sheet swings up over the binding in 3D, darkening as it
       turns away from the light and showing its back, while the next month waits underneath in the shadow of the lifting
       page. The arrow up brings last month's sheet back down over this one. A swipe up or down on the pad does the same.
       Pressing a day circles it with a red marker, by hand: a slightly shaky ring that runs a little past where it began;
       choosing another day rubs the old ring out.
       The turning page is the sheet itself, moved into a box with a back face that turns with rotateX around the top edge
       inside a perspective; the ring is an SVG path made from an ellipse with a little noise, drawn with
       stroke-dashoffset, always the same for the same day. The arrow keys move between the days, Page Up and Page Down
       turn the pages, Enter circles. */

    /* ---- values to change ---- */
    const WEEK_START = 1;           /* the first day of the week: 1 Monday, 0 Sunday */
    const FLIP = 1;                 /* the seconds of a page turning */
    const LIGHT = 0.35;             /* how dark a page gets as it turns away from the light, and the shadow it throws */
    const INK = 0.6;                /* the seconds the marker takes to draw a ring */
    const WOBBLE = 0.07;            /* how shaky the hand is: 0 draws a perfect ellipse */
    const DEPTH = 1600;             /* the perspective, in pixels: smaller, the more the page comes towards you */

    const REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const cal = container.value.querySelector('[data-calendar]');
    const pad = cal.querySelector('[data-pad]');
    const sheets = cal.querySelector('[data-sheets]');
    const wire = cal.querySelector('[data-wire]');
    const prevBtn = cal.querySelector('[data-prev]');
    const nextBtn = cal.querySelector('[data-next]');
    const said = cal.querySelector('[data-said]');
    document.documentElement.style.setProperty('--depth', `${DEPTH}px`);

    /* ---------------------------------------------------------------- dates */
    const pad2 = (n) => String(n).padStart(2, '0');
    const iso = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
    const dateOf = (s) => {
      const [y, m, d] = s.split('-').map(Number);
      return new Date(y, m - 1, d);
    };
    const plus = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
    const monthOf = (d) => new Date(d.getFullYear(), d.getMonth(), 1);
    const now = new Date();
    const fmt = {
      month: new Intl.DateTimeFormat('en-GB', { month: 'long' }),
      long: new Intl.DateTimeFormat('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }),
      letter: new Intl.DateTimeFormat('en-GB', { weekday: 'narrow' }),
    };
    /* the week's initials from WEEK_START on (1 January 2023 was a Sunday), and the column Sunday falls in */
    const week = Array.from({ length: 7 }, (_, i) => fmt.letter.format(new Date(2023, 0, 1 + ((WEEK_START + i) % 7))));
    const sundayCol = (7 - WEEK_START) % 7;

    let shown = monthOf(now);                   /* the month on the pad */
    let picked = iso(plus(now, 5));             /* a day already circled when the page opens */
    let current = null;                         /* the sheet on top */
    let busy = null;                            /* the page turning, while it turns */

    /* ---------------------------------------------------------------- a sheet */
    function sheetEl(m0) {
      const y = m0.getFullYear();
      const m = m0.getMonth();
      const days = new Date(y, m + 1, 0).getDate();
      const lead = (m0.getDay() - WEEK_START + 7) % 7;
      const el = document.createElement('section');
      el.className = 'sheet';
      el.setAttribute('aria-label', `${fmt.month.format(m0)} ${y}`);
      let html = `<span class="sheet__year">${y}</span><h2 class="sheet__month">${fmt.month.format(m0)}</h2>`;
      html += `<div class="sheet__week" aria-hidden="true">${week.map((w, i) => `<span${i === sundayCol ? ' class="is-sunday"' : ''}>${w}</span>`).join('')}</div><div class="sheet__days">`;
      for (let i = 0; i < 42; i++) {
        const n = i - lead + 1;
        if (n < 1 || n > days) {
          html += '<span aria-hidden="true"></span>';
          continue;
        }
        const s = `${y}-${pad2(m + 1)}-${pad2(n)}`;
        html += `<button class="date${i % 7 === sundayCol ? ' is-sunday' : ''}" type="button" tabindex="-1" data-date="${s}" aria-label="${fmt.long.format(dateOf(s))}" aria-pressed="${s === picked}">${n}</button>`;
      }
      el.innerHTML = `${html}</div><svg class="sheet__ink" aria-hidden="true"></svg><span class="sheet__shade" aria-hidden="true"></span>`;
      return el;
    }

    /* ---------------------------------------------------------------- the marker */
    function rand(a) {
      return () => {
        a = (a + 0x6d2b79f5) | 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      };
    }
    /* a ring drawn by hand: an ellipse, tilted, a little shaky, that runs 14% past where it began, always the same for
       the same day */
    function ringPath(cx, cy, r, day) {
      const rnd = rand(day.split('-').reduce((a, v) => a * 37 + Number(v), 7));
      const tilt = (rnd() - 0.5) * 0.6;
      const begin = rnd() * Math.PI * 2;
      const rx = r * (1.06 + rnd() * 0.1);
      const ry = r * (0.84 + rnd() * 0.08);
      const phase = rnd() * 6;
      const steps = 72;
      let d = '';
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const a = begin + t * Math.PI * 2 * 1.14;
        const w = 1 + WOBBLE * (Math.sin(t * 9 + phase) * 0.6 + (rnd() - 0.5) * 0.5) + t * 0.06;
        const x0 = Math.cos(a) * rx * w;
        const y0 = Math.sin(a) * ry * w;
        d += `${i ? 'L' : 'M'}${(cx + x0 * Math.cos(tilt) - y0 * Math.sin(tilt)).toFixed(1)} ${(cy + x0 * Math.sin(tilt) + y0 * Math.cos(tilt)).toFixed(1)}`;
      }
      return d;
    }
    function addRing(sheet, draw) {
      const b = picked && sheet.querySelector(`.date[data-date="${picked}"]`);
      if (!b) return;
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', ringPath(b.offsetLeft + b.offsetWidth / 2, b.offsetTop + b.offsetHeight / 2, Math.min(b.offsetWidth, b.offsetHeight) * 0.42, picked));
      sheet.querySelector('.sheet__ink').appendChild(path);
      const len = path.getTotalLength();
      path.style.strokeDasharray = `${len}`;
      path.style.strokeDashoffset = draw && !REDUCED ? `${len}` : '0';
      if (draw && !REDUCED) gsap.to(path, { strokeDashoffset: 0, duration: INK, ease: 'power1.inOut' });
    }

    function choose(s) {
      if (s === picked) return;
      const old = current.querySelector('.sheet__ink path');
      picked = s;
      current.querySelectorAll('.date').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.date === s)));
      /* the old ring is rubbed out, running back to where it began */
      if (old && !REDUCED) gsap.to(old, { strokeDashoffset: old.getTotalLength(), duration: 0.25, ease: 'power2.in', onComplete: () => old.remove() });
      else if (old) old.remove();
      addRing(current, true);
      said.textContent = `${fmt.long.format(dateOf(s))}, circled.`;
    }

    /* ---------------------------------------------------------------- turning the pages */
    function place(sheet) {
      current = sheet;
      sheet.querySelector('.date[data-date$="-18"]')?.setAttribute('data-autoclic', '');   /* for the library's automatic preview */
      roving();
    }
    function turn(dir) {
      if (busy) busy.progress(1);
      shown = new Date(shown.getFullYear(), shown.getMonth() + dir, 1);
      said.textContent = `${fmt.month.format(shown)} ${shown.getFullYear()}`;
      const fresh = sheetEl(shown);
      const old = current;
      old.inert = true;
      old.querySelectorAll('[data-autoclic]').forEach((b) => b.removeAttribute('data-autoclic'));
      if (REDUCED) {
        sheets.appendChild(fresh);
        addRing(fresh, false);
        place(fresh);
        gsap.fromTo(fresh, { opacity: 0 }, { opacity: 1, duration: 0.25, onComplete: () => old.remove() });
        return;
      }
      /* the page that moves goes into a box with a back face: forward it is this month, lifting up and over the binding;
         backward it is last month, coming down from up there onto this one */
      const flip = document.createElement('div');
      flip.className = 'flip';
      const back = document.createElement('span');
      back.className = 'flip__back';
      const moving = dir > 0 ? old : fresh;
      const below = dir > 0 ? fresh : old;
      if (dir > 0) sheets.insertBefore(fresh, old);
      sheets.appendChild(flip);
      flip.append(moving, back);
      addRing(fresh, false);
      if (dir > 0) place(fresh);
      const topShade = moving.querySelector('.sheet__shade');
      const lowShade = below.querySelector('.sheet__shade');
      const turnState = { a: dir > 0 ? 0 : 180 };
      /* the fading at the end goes on the two faces: opacity on the 3D box would flatten it, and the front would show
         through the back */
      const draw = () => {
        const a = turnState.a;
        const fade = a > 120 ? (1 - (a - 120) / 60).toFixed(3) : '1';
        gsap.set(flip, { rotationX: a });
        moving.style.opacity = fade;
        back.style.opacity = fade;
        topShade.style.opacity = (LIGHT * Math.min(1, a / 90)).toFixed(3);
        lowShade.style.opacity = (LIGHT * 0.8 * Math.sin((a * Math.PI) / 180)).toFixed(3);
      };
      draw();
      busy = gsap.to(turnState, {
        a: dir > 0 ? 180 : 0,
        duration: FLIP,
        ease: 'power2.inOut',
        onUpdate: draw,
        onComplete: () => {
          busy = null;
          lowShade.style.opacity = '0';
          topShade.style.opacity = '0';
          moving.style.removeProperty('opacity');
          if (dir > 0) {
            flip.remove();
          } else {
            sheets.appendChild(fresh);
            flip.remove();
            old.remove();
            place(fresh);
          }
          if (cal.contains(document.activeElement) && document.activeElement.classList.contains('date') === false && keys) focusDay();
        },
      });
    }
    prevBtn.addEventListener('click', () => turn(-1));
    nextBtn.addEventListener('click', () => turn(1));

    /* a swipe on the pad: up turns forward, down turns back (and the tap that ends it chooses nothing) */
    let swipeFrom = null;
    let swiped = 0;
    pad.addEventListener('pointerdown', (e) => { if (e.pointerType !== 'mouse') swipeFrom = e.clientY; });
    pad.addEventListener('pointerup', (e) => {
      if (swipeFrom === null) return;
      const dy = e.clientY - swipeFrom;
      swipeFrom = null;
      if (Math.abs(dy) < 40) return;
      swiped = performance.now();
      turn(dy < 0 ? 1 : -1);
    });
    pad.addEventListener('pointercancel', () => { swipeFrom = null; });

    sheets.addEventListener('click', (e) => {
      const b = e.target.closest('.date');
      if (!b || !current.contains(b) || performance.now() - swiped < 400) return;
      focusDate = b.dataset.date;
      choose(b.dataset.date);
    });

    /* ---------------------------------------------------------------- the keyboard */
    let focusDate = picked;
    let keys = false;
    cal.addEventListener('pointerdown', () => { keys = false; });
    function roving() {
      const days = [...current.querySelectorAll('.date')];
      const want = days.find((b) => b.dataset.date === focusDate) || days.find((b) => b.dataset.date === picked) || days[0];
      days.forEach((b) => { b.tabIndex = b === want ? 0 : -1; });
    }
    function focusDay() {
      current.querySelector('.date[tabindex="0"]')?.focus();
    }
    sheets.addEventListener('keydown', (e) => {
      const b = e.target.closest('.date');
      if (!b) return;
      const d = dateOf(b.dataset.date);
      const col = (d.getDay() - WEEK_START + 7) % 7;
      const moves = {
        ArrowLeft: () => plus(d, -1),
        ArrowRight: () => plus(d, 1),
        ArrowUp: () => plus(d, -7),
        ArrowDown: () => plus(d, 7),
        Home: () => plus(d, -col),
        End: () => plus(d, 6 - col),
        PageUp: () => new Date(d.getFullYear(), d.getMonth() - 1, Math.min(d.getDate(), 28)),
        PageDown: () => new Date(d.getFullYear(), d.getMonth() + 1, Math.min(d.getDate(), 28)),
      };
      if (!moves[e.key]) return;
      e.preventDefault();
      keys = true;
      const to = moves[e.key]();
      focusDate = iso(to);
      const m = monthOf(to);
      if (m.getTime() !== shown.getTime()) {
        turn(m > shown ? 1 : -1);
        if (busy) busy.progress(1);
      }
      roving();
      focusDay();
    });

    /* ---------------------------------------------------------------- the wire binding, drawn for the pad's width */
    function drawWire() {
      const w = wire.getBoundingClientRect().width;
      const loops = Math.max(8, Math.round(w / 24));
      let svg = '';
      for (let i = 0; i < loops; i++) {
        const x = ((i + 0.5) * w) / loops;
        svg += `<rect x="${(x - 5).toFixed(1)}" y="19" width="10" height="6" rx="2.5" fill="#1c1a17" opacity="0.85"/>`;
        for (const dx of [-2.2, 2.2]) {
          const xx = (x + dx).toFixed(1);
          svg += `<path d="M${xx} 23 C${xx} 2, ${(x + dx * 1.6).toFixed(1)} 2, ${(x + dx * 1.6).toFixed(1)} 12" fill="none" stroke="#9da1a8" stroke-width="2.6" stroke-linecap="round"/>`;
          svg += `<path d="M${xx} 21 C${xx} 4, ${(x + dx * 1.6).toFixed(1)} 4, ${(x + dx * 1.6).toFixed(1)} 11" fill="none" stroke="#e6e8ec" stroke-width="0.9" stroke-linecap="round"/>`;
        }
      }
      wire.innerHTML = svg;
    }

    /* ---------------------------------------------------------------- the pad arrives, and the marker circles a day */
    const first = sheetEl(shown);
    sheets.appendChild(first);
    place(first);
    drawWire();
    addRing(first, false);
    addPageListener(window, 'resize', () => {
      drawWire();
      const ink = current.querySelector('.sheet__ink');
      ink.innerHTML = '';
      addRing(current, false);
    });
    if (!REDUCED) {
      const ring = current.querySelector('.sheet__ink path');
      gsap.from(pad, { y: -40, rotationX: -12, transformPerspective: 1200, transformOrigin: '50% 0%', autoAlpha: 0, duration: 1.1, ease: 'power3.out' });
      gsap.from('.calendar__nav', { autoAlpha: 0, y: 12, duration: 0.7, ease: 'power3.out', delay: 0.3 });
      if (ring) gsap.fromTo(ring, { strokeDashoffset: ring.getTotalLength() }, { strokeDashoffset: 0, duration: INK, ease: 'power1.inOut', delay: 0.75 });
    }

    return () => {
      cleanups.forEach((undo) => undo());
    };
  }, container.value);
});

onBeforeUnmount(() => ctx.revert());
</script>

<template>
  <div ref="container" style="display: contents">
    <main class="stage">
      <div class="calendar" data-calendar>
        <div class="calendar__nav">
          <button class="calendar__arrow" type="button" aria-label="Previous month" data-prev><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 15l6-6 6 6"/></svg></button>
          <button class="calendar__arrow" type="button" aria-label="Next month" data-next data-autoclic><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>
        </div>

        <div class="pad" data-pad>
          <div class="pad__sheets" data-sheets></div>
          <svg class="pad__wire" data-wire aria-hidden="true"></svg>
        </div>
        <p class="sr" role="status" aria-live="polite" data-said></p>
      </div>
    </main>
  </div>
</template>

<!-- not scoped: the script builds part of the markup itself, and those elements would miss Vue's scoped attribute -->
<style>
/* The paper calendar: a wall calendar on a black page. The months turn like real sheets, swinging up over the wire
   binding in 3D, and the day you choose gets circled by hand with a red marker. */
:root {
  --page: #000000;          /* the page */
  --paper: #f3eee3;         /* the sheet */
  --paper-back: #e4dccb;    /* the back of a sheet */
  --ink: #1c1a17;           /* the print */
  --red: #cf3a2a;           /* Sundays, and the marker */
  --muted: rgba(28, 26, 23, 0.45);
  --wire: #b9bcc2;
  --depth: 1600px;          /* set by the script: the perspective */
}

* {
  box-sizing: border-box;
}

html,
body {
  margin: 0;
  overflow-x: clip;
}

body {
  min-height: 100svh;
  background: var(--page);
  color: var(--paper);
  font-family: 'Fraunces Variable', Georgia, serif;
  -webkit-font-smoothing: antialiased;
}

.sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}

.stage {
  min-height: 100svh;
  display: grid;
  place-items: center;
  padding: 48px 20px;
}

.calendar {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 30px;
}

/* ---------------------------------------------------------------- the arrows */
.calendar__nav {
  order: 2;
  display: flex;
  gap: 14px;
}

.calendar__arrow {
  display: grid;
  place-items: center;
  width: 52px;
  height: 52px;
  padding: 0;
  border: 0;
  border-radius: 50%;
  background: transparent;
  box-shadow: inset 0 0 0 1.5px rgba(243, 238, 227, 0.35);
  color: var(--paper);
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  touch-action: manipulation;
  transition: box-shadow 0.25s ease, background-color 0.25s ease, transform 0.35s cubic-bezier(0.34, 1.6, 0.5, 1);
}

.calendar__arrow svg {
  width: 22px;
  height: 22px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}

@media (hover: hover) and (pointer: fine) {
  .calendar__arrow:hover {
    background: rgba(243, 238, 227, 0.08);
    box-shadow: inset 0 0 0 1.5px rgba(243, 238, 227, 0.8);
    transform: translateY(-2px);
  }
}

.calendar__arrow:active {
  transform: scale(0.94);
}

.calendar__arrow:focus-visible {
  outline: 2px solid var(--paper);
  outline-offset: 3px;
}

/* ---------------------------------------------------------------- the pad */
.pad {
  position: relative;
  width: min(430px, calc(100vw - 40px));
  aspect-ratio: 0.82;
  touch-action: none;
}

/* the edges of the sheets below, peeking out at the bottom */
.pad::before,
.pad::after {
  content: '';
  position: absolute;
  left: 2%;
  right: 2%;
  bottom: -5px;
  height: 20px;
  border-radius: 0 0 10px 10px;
  background: #d8cfbd;
}

.pad::after {
  left: 4%;
  right: 4%;
  bottom: -10px;
  background: #b9b09f;
}

.pad__sheets {
  position: absolute;
  inset: 0;
  z-index: 1;
  perspective: var(--depth);
  perspective-origin: 50% 0%;
}

/* a sheet: the paper, a little darker at the edges */
.sheet {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  padding: 13% 7.5% 6%;
  border-radius: 6px 6px 12px 12px;
  background:
    radial-gradient(120% 90% at 50% 40%, rgba(255, 255, 255, 0.35), rgba(255, 255, 255, 0) 60%),
    var(--paper);
  color: var(--ink);
  box-shadow: 0 30px 60px -30px rgba(0, 0, 0, 0.9);
  transform-origin: 50% 0;
}

/* the light on a sheet while it turns, and the shadow on the one below */
.sheet__shade {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: linear-gradient(180deg, rgba(0, 0, 0, 0.55), rgba(0, 0, 0, 0.15));
  opacity: 0;
  pointer-events: none;
}

.sheet__year {
  font-size: clamp(12px, 3.2vw, 14px);
  font-weight: 600;
  letter-spacing: 0.3em;
  color: var(--muted);
}

.sheet__month {
  margin: 0.1em 0 0.35em;
  font-size: clamp(46px, 13.5vw, 74px);
  font-style: italic;
  font-weight: 420;
  line-height: 0.95;
  letter-spacing: -0.02em;
}

.sheet__week,
.sheet__days {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
}

.sheet__week {
  padding-bottom: 0.6em;
  border-bottom: 1px solid rgba(28, 26, 23, 0.14);
  margin-bottom: 0.4em;
  font-size: clamp(11px, 3vw, 13px);
  font-weight: 650;
  letter-spacing: 0.08em;
  text-align: center;
  color: var(--muted);
}

.sheet__days {
  flex: 1;
  grid-template-rows: repeat(6, 1fr);
}

.sheet__week .is-sunday {
  color: var(--red);
}

.date {
  position: relative;
  display: grid;
  place-items: center;
  padding: 0;
  border: 0;
  border-radius: 50%;
  background: transparent;
  color: var(--ink);
  font: inherit;
  font-size: clamp(17px, 5vw, 23px);
  font-weight: 450;
  font-variant-numeric: lining-nums;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  touch-action: manipulation;
  transition: color 0.2s ease, transform 0.35s cubic-bezier(0.34, 1.6, 0.5, 1);
}

.date.is-sunday {
  color: var(--red);
}

@media (hover: hover) and (pointer: fine) {
  .date:hover {
    transform: translateY(-2px) rotate(-3deg);
  }
}

.date:focus-visible {
  outline: 2px dashed var(--ink);
  outline-offset: -4px;
}

/* the marker: a hand-drawn ring over the sheet */
.sheet__ink {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
  fill: none;
  stroke: var(--red);
  stroke-width: 2.6;
  stroke-linecap: round;
  stroke-linejoin: round;
  pointer-events: none;
}

.sheet__ink path {
  opacity: 0.92;
}

/* the back of a sheet, seen while it swings over the binding */
.flip {
  position: absolute;
  inset: 0;
  z-index: 3;
  transform-origin: 50% 0;
  transform-style: preserve-3d;
  pointer-events: none;
}

.flip .sheet {
  backface-visibility: hidden;
  -webkit-backface-visibility: hidden;
}

.flip__back {
  position: absolute;
  inset: 0;
  border-radius: 12px 12px 6px 6px;
  background: var(--paper-back);
  transform: rotateX(180deg);
  backface-visibility: hidden;
  -webkit-backface-visibility: hidden;
}

/* the wire binding across the top */
.pad__wire {
  position: absolute;
  left: 4%;
  right: 4%;
  top: -14px;
  z-index: 4;
  width: 92%;
  height: 34px;
  overflow: visible;
  pointer-events: none;
}

@media (max-width: 480px) {
  .calendar {
    gap: 24px;
  }
}
</style>
