# Il calendario a fogli

Su un fondo nero un calendario da muro: un foglio color crema appeso a una spirale di metallo, con i bordi dei fogli sotto che spuntano in fondo. Sul foglio ci sono l’anno, il nome del mese in corsivo, le iniziali dei giorni e i numeri, con la domenica in rosso; sotto, due frecce. La freccia giù gira pagina: il foglio si alza ruotando intorno al suo bordo in alto, passa sopra la spirale scurendosi man mano che si allontana dalla luce, mostra il retro e svanisce, mentre il mese dopo aspetta sotto, nell’ombra del foglio che si alza. La freccia su riporta giù il foglio del mese prima sopra questo. Anche uno scorrimento del dito sul calendario gira pagina: verso l’alto avanti, verso il basso indietro. Sotto il puntatore un numero si alza e si inclina un poco. Premendo un giorno, un pennarello rosso lo cerchia a mano: un anello un po’ storto e tremolante che va un poco oltre il punto da cui è partito; scegliendo un altro giorno il cerchio vecchio si cancella tornando indietro. All’apertura il calendario scende dall’alto e il pennarello cerchia un giorno.

## Come si usa

Apri index.html in un browser. Le librerie arrivano da jsDelivr: in produzione puoi scaricarle e servirle dal tuo dominio.

## Come funziona

- **Il foglio.** Ogni mese è una sezione disegnata dallo script: l’anno, il mese, le iniziali dei giorni da WEEK_START in poi e sei settimane di pulsanti. Sopra i giorni ci sono un SVG vuoto per l’inchiostro e un velo scuro per l’ombra. La spirale è un SVG ridisegnato sulla larghezza del calendario: un anello ogni 24 pixel circa, ognuno col suo buco nella carta e due fili.
- **La pagina che gira.** Il foglio che si muove va in una scatola con transform-style: preserve-3d e il punto di rotazione sul bordo in alto, insieme a una faccia di retro girata di 180 gradi; tutte e due hanno backface-visibility: hidden. Un numero va da 0 a 180 gradi in FLIP secondi con power2.inOut e a ogni fotogramma diventa la rotationX della scatola. Il contenitore ha la prospettiva (DEPTH pixel) vista dal bordo in alto, così il foglio si alza verso di te.
- **Luce e ombra.** Lo stesso numero scurisce il foglio che gira, con un velo che arriva a LIGHT a 90 gradi, e il foglio sotto, con LIGHT per 0,8 per il seno dell’angolo: l’ombra c’è finché il foglio è sollevato. Oltre i 120 gradi le due facce svaniscono, ognuna per conto suo.
- **Il pennarello.** L’anello è un’ellisse di 72 punti un po’ inclinata, con un tremolio fatto da un seno e da un po’ di caso (WOBBLE), che fa 1,14 giri e si allarga un poco mentre gira. Il caso viene da un generatore col seme preso dalla data, così lo stesso giorno ha sempre lo stesso anello. Si disegna portando lo stroke-dashoffset dalla lunghezza del tratto a zero in INK secondi, e si cancella al contrario.
- **Tastiera e dito.** Le frecce vengono prima del calendario nel codice (e sotto sullo schermo, con order), così il tasto Tab le trova per prime; poi un solo giorno prende il Tab: le frecce della tastiera si muovono fra i giorni, Pagina su e Pagina giù girano pagina, Invio cerchia. Col dito uno scorrimento di almeno 40 pixel gira pagina, e il tocco con cui finisce non sceglie nessun giorno.

## Valori da cambiare

- `WEEK_START` (script.js, di partenza 1): Il primo giorno della settimana: 1 il lunedì, 0 la domenica.
- `FLIP` (script.js, di partenza 1): I secondi di una pagina che gira.
- `LIGHT` (script.js, di partenza 0.35): Quanto si scurisce un foglio che si allontana dalla luce, e l’ombra che getta su quello sotto.
- `INK` (script.js, di partenza 0.6): I secondi in cui il pennarello disegna un anello.
- `WOBBLE` (script.js, di partenza 0.07): Quanto trema la mano: 0 disegna un’ellisse perfetta.
- `DEPTH` (script.js, di partenza 1600): La prospettiva, in pixel: più è piccola, più il foglio viene verso di te.

## Trappole

- L’opacità sulla scatola in 3D la appiattisce: il fronte si vedrebbe attraverso il retro, a specchio e scuro. Per questo la dissolvenza finale va sulle due facce, una per una, e mai sulla scatola.
- Il foglio che gira è proprio quello di prima, spostato nella scatola: niente copie da tenere allineate. Tornando indietro è il foglio del mese prima che entra nella scatola già girato di 180 gradi e scende.
- L’anello si disegna sulle misure del giorno dentro il foglio (offsetLeft, offsetTop), non sul rettangolo sullo schermo, che durante la rotazione è deformato dalla prospettiva; quando cambia la finestra lo si ridisegna.
- Una pagina girata mentre l’altra gira ancora porta subito quella alla fine (progress(1)): due pagine in volo insieme si incastrerebbero.

---

# The paper calendar

On a black background a wall calendar: a cream sheet hanging from a metal wire binding, with the edges of the sheets below peeking out at the bottom. On the sheet are the year, the name of the month in italics, the initials of the days and the numbers, with Sundays in red; below, two arrows. The arrow down turns the page: the sheet lifts up turning around its top edge, goes over the binding darkening as it turns away from the light, shows its back and fades, while the next month waits underneath, in the shadow of the lifting sheet. The arrow up brings last month’s sheet back down over this one. A swipe on the calendar turns the page too: upwards forward, downwards back. Under the pointer a number lifts and tilts a little. Pressing a day, a red marker circles it by hand: a slightly crooked, shaky ring that runs a little past where it began; choosing another day the old ring rubs out running backwards. When the page opens the calendar comes down from above and the marker circles a day.

## How to use it

Open index.html in a browser. Libraries load from jsDelivr: in production you can download them and serve them from your own domain.

## How it works

- **The sheet.** Each month is a section drawn by the script: the year, the month, the initials of the days from WEEK_START on and six weeks of buttons. Over the days sit an empty SVG for the ink and a dark veil for the shadow. The binding is an SVG drawn again for the width of the calendar: a loop about every 24 pixels, each with its hole in the paper and two wires.
- **The turning page.** The moving sheet goes into a box with transform-style: preserve-3d and its pivot on the top edge, together with a back face turned by 180 degrees; both have backface-visibility: hidden. A number goes from 0 to 180 degrees in FLIP seconds with power2.inOut, and on every frame it becomes the box’s rotationX. The container has the perspective (DEPTH pixels) seen from the top edge, so the sheet lifts towards you.
- **Light and shadow.** The same number darkens the turning sheet, with a veil that reaches LIGHT at 90 degrees, and the sheet below, with LIGHT times 0.8 times the sine of the angle: the shadow is there while the sheet is lifted. Past 120 degrees the two faces fade, each on its own.
- **The marker.** The ring is an ellipse of 72 points, slightly tilted, with a shake made of a sine and a little chance (WOBBLE), that goes round 1.14 times and widens a little as it goes. The chance comes from a generator seeded with the date, so the same day always gets the same ring. It is drawn by taking the stroke-dashoffset from the length of the stroke to zero in INK seconds, and rubbed out the other way.
- **Keyboard and finger.** The arrows come before the calendar in the code (and below it on screen, with order), so the Tab key finds them first; then a single day takes the Tab key: the arrow keys move between the days, Page Up and Page Down turn the pages, Enter circles. With a finger a swipe of at least 40 pixels turns the page, and the tap it ends with chooses no day.

## Values to change

- `WEEK_START` (script.js, default 1): The first day of the week: 1 Monday, 0 Sunday.
- `FLIP` (script.js, default 1): The seconds of a page turning.
- `LIGHT` (script.js, default 0.35): How dark a sheet gets as it turns away from the light, and the shadow it throws on the one below.
- `INK` (script.js, default 0.6): The seconds the marker takes to draw a ring.
- `WOBBLE` (script.js, default 0.07): How shaky the hand is: 0 draws a perfect ellipse.
- `DEPTH` (script.js, default 1600): The perspective, in pixels: the smaller it is, the more the sheet comes towards you.

## Pitfalls

- Opacity on the 3D box flattens it: the front would show through the back, mirrored and dark. That is why the final fade goes on the two faces, one by one, and never on the box.
- The turning sheet is the very sheet that was there, moved into the box: no copies to keep aligned. Going back, it is last month’s sheet that goes into the box already turned by 180 degrees and comes down.
- The ring is drawn on the day’s measures inside the sheet (offsetLeft, offsetTop), not on its rectangle on the screen, which the perspective distorts during the turn; when the window changes it is drawn again.
- A page turned while another is still turning sends that one straight to its end (progress(1)): two pages in the air at once would get stuck in each other.

Animorio, 2026