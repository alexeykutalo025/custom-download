/*
  "The paper calendar" from Animorio · https://animorio.com
  License: free on your own sites and your clients’ sites, paid work included.
  Not for resale, redistribution, templates or code collections · https://animorio.com/en/license/
*/
/* The paper calendar
   A wall calendar on a black page: a cream sheet for each month hanging from a wire binding, with the edges of the
   sheets below peeking out. The arrow down turns the page: the sheet swings up over the binding in 3D, darkening as it
   turns away from the light and showing its back, while the next month waits underneath in the shadow of the lifting
   page. The arrow up brings last month's sheet back down over this one. A swipe up or down on the pad does the same.
   Pressing a day circles it with a red marker, by hand: a slightly shaky ring that runs a little past where it began;
   choosing another day rubs the old ring out.
   The turning page is the sheet itself, moved into a box with a back face that turns with rotateX around the top edge
   inside a perspective; the ring is an SVG path made from an ellipse with a little noise, drawn with
   stroke-dashoffset, always the same for the same day. The arrow keys move between the days, Page Up and Page Down
   turn the pages, Enter circles. */

/* ---- values to change ---- */
const WEEK_START = 1;           /* the first day of the week: 1 Monday, 0 Sunday */
const FLIP = 1;                 /* the seconds of a page turning */
const LIGHT = 0.35;             /* how dark a page gets as it turns away from the light, and the shadow it throws */
const INK = 0.6;                /* the seconds the marker takes to draw a ring */
const WOBBLE = 0.07;            /* how shaky the hand is: 0 draws a perfect ellipse */
const DEPTH = 1600;             /* the perspective, in pixels: smaller, the more the page comes towards you */

const REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;
const cal = document.querySelector('[data-calendar]');
const pad = cal.querySelector('[data-pad]');
const sheets = cal.querySelector('[data-sheets]');
const wire = cal.querySelector('[data-wire]');
const prevBtn = cal.querySelector('[data-prev]');
const nextBtn = cal.querySelector('[data-next]');
const said = cal.querySelector('[data-said]');
document.documentElement.style.setProperty('--depth', `${DEPTH}px`);

/* ---------------------------------------------------------------- dates */
const pad2 = (n) => String(n).padStart(2, '0');
const iso = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const dateOf = (s) => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
};
const plus = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const monthOf = (d) => new Date(d.getFullYear(), d.getMonth(), 1);
const now = new Date();
const fmt = {
  month: new Intl.DateTimeFormat('en-GB', { month: 'long' }),
  long: new Intl.DateTimeFormat('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }),
  letter: new Intl.DateTimeFormat('en-GB', { weekday: 'narrow' }),
};
/* the week's initials from WEEK_START on (1 January 2023 was a Sunday), and the column Sunday falls in */
const week = Array.from({ length: 7 }, (_, i) => fmt.letter.format(new Date(2023, 0, 1 + ((WEEK_START + i) % 7))));
const sundayCol = (7 - WEEK_START) % 7;

let shown = monthOf(now);                   /* the month on the pad */
let picked = iso(plus(now, 5));             /* a day already circled when the page opens */
let current = null;                         /* the sheet on top */
let busy = null;                            /* the page turning, while it turns */

/* ---------------------------------------------------------------- a sheet */
function sheetEl(m0) {
  const y = m0.getFullYear();
  const m = m0.getMonth();
  const days = new Date(y, m + 1, 0).getDate();
  const lead = (m0.getDay() - WEEK_START + 7) % 7;
  const el = document.createElement('section');
  el.className = 'sheet';
  el.setAttribute('aria-label', `${fmt.month.format(m0)} ${y}`);
  let html = `<span class="sheet__year">${y}</span><h2 class="sheet__month">${fmt.month.format(m0)}</h2>`;
  html += `<div class="sheet__week" aria-hidden="true">${week.map((w, i) => `<span${i === sundayCol ? ' class="is-sunday"' : ''}>${w}</span>`).join('')}</div><div class="sheet__days">`;
  for (let i = 0; i < 42; i++) {
    const n = i - lead + 1;
    if (n < 1 || n > days) {
      html += '<span aria-hidden="true"></span>';
      continue;
    }
    const s = `${y}-${pad2(m + 1)}-${pad2(n)}`;
    html += `<button class="date${i % 7 === sundayCol ? ' is-sunday' : ''}" type="button" tabindex="-1" data-date="${s}" aria-label="${fmt.long.format(dateOf(s))}" aria-pressed="${s === picked}">${n}</button>`;
  }
  el.innerHTML = `${html}</div><svg class="sheet__ink" aria-hidden="true"></svg><span class="sheet__shade" aria-hidden="true"></span>`;
  return el;
}

/* ---------------------------------------------------------------- the marker */
function rand(a) {
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
/* a ring drawn by hand: an ellipse, tilted, a little shaky, that runs 14% past where it began, always the same for
   the same day */
function ringPath(cx, cy, r, day) {
  const rnd = rand(day.split('-').reduce((a, v) => a * 37 + Number(v), 7));
  const tilt = (rnd() - 0.5) * 0.6;
  const begin = rnd() * Math.PI * 2;
  const rx = r * (1.06 + rnd() * 0.1);
  const ry = r * (0.84 + rnd() * 0.08);
  const phase = rnd() * 6;
  const steps = 72;
  let d = '';
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const a = begin + t * Math.PI * 2 * 1.14;
    const w = 1 + WOBBLE * (Math.sin(t * 9 + phase) * 0.6 + (rnd() - 0.5) * 0.5) + t * 0.06;
    const x0 = Math.cos(a) * rx * w;
    const y0 = Math.sin(a) * ry * w;
    d += `${i ? 'L' : 'M'}${(cx + x0 * Math.cos(tilt) - y0 * Math.sin(tilt)).toFixed(1)} ${(cy + x0 * Math.sin(tilt) + y0 * Math.cos(tilt)).toFixed(1)}`;
  }
  return d;
}
function addRing(sheet, draw) {
  const b = picked && sheet.querySelector(`.date[data-date="${picked}"]`);
  if (!b) return;
  const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  path.setAttribute('d', ringPath(b.offsetLeft + b.offsetWidth / 2, b.offsetTop + b.offsetHeight / 2, Math.min(b.offsetWidth, b.offsetHeight) * 0.42, picked));
  sheet.querySelector('.sheet__ink').appendChild(path);
  const len = path.getTotalLength();
  path.style.strokeDasharray = `${len}`;
  path.style.strokeDashoffset = draw && !REDUCED ? `${len}` : '0';
  if (draw && !REDUCED) gsap.to(path, { strokeDashoffset: 0, duration: INK, ease: 'power1.inOut' });
}

function choose(s) {
  if (s === picked) return;
  const old = current.querySelector('.sheet__ink path');
  picked = s;
  current.querySelectorAll('.date').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.date === s)));
  /* the old ring is rubbed out, running back to where it began */
  if (old && !REDUCED) gsap.to(old, { strokeDashoffset: old.getTotalLength(), duration: 0.25, ease: 'power2.in', onComplete: () => old.remove() });
  else if (old) old.remove();
  addRing(current, true);
  said.textContent = `${fmt.long.format(dateOf(s))}, circled.`;
}

/* ---------------------------------------------------------------- turning the pages */
function place(sheet) {
  current = sheet;
  sheet.querySelector('.date[data-date$="-18"]')?.setAttribute('data-autoclic', '');   /* for the library's automatic preview */
  roving();
}
function turn(dir) {
  if (busy) busy.progress(1);
  shown = new Date(shown.getFullYear(), shown.getMonth() + dir, 1);
  said.textContent = `${fmt.month.format(shown)} ${shown.getFullYear()}`;
  const fresh = sheetEl(shown);
  const old = current;
  old.inert = true;
  old.querySelectorAll('[data-autoclic]').forEach((b) => b.removeAttribute('data-autoclic'));
  if (REDUCED) {
    sheets.appendChild(fresh);
    addRing(fresh, false);
    place(fresh);
    gsap.fromTo(fresh, { opacity: 0 }, { opacity: 1, duration: 0.25, onComplete: () => old.remove() });
    return;
  }
  /* the page that moves goes into a box with a back face: forward it is this month, lifting up and over the binding;
     backward it is last month, coming down from up there onto this one */
  const flip = document.createElement('div');
  flip.className = 'flip';
  const back = document.createElement('span');
  back.className = 'flip__back';
  const moving = dir > 0 ? old : fresh;
  const below = dir > 0 ? fresh : old;
  if (dir > 0) sheets.insertBefore(fresh, old);
  sheets.appendChild(flip);
  flip.append(moving, back);
  addRing(fresh, false);
  if (dir > 0) place(fresh);
  const topShade = moving.querySelector('.sheet__shade');
  const lowShade = below.querySelector('.sheet__shade');
  const turnState = { a: dir > 0 ? 0 : 180 };
  /* the fading at the end goes on the two faces: opacity on the 3D box would flatten it, and the front would show
     through the back */
  const draw = () => {
    const a = turnState.a;
    const fade = a > 120 ? (1 - (a - 120) / 60).toFixed(3) : '1';
    gsap.set(flip, { rotationX: a });
    moving.style.opacity = fade;
    back.style.opacity = fade;
    topShade.style.opacity = (LIGHT * Math.min(1, a / 90)).toFixed(3);
    lowShade.style.opacity = (LIGHT * 0.8 * Math.sin((a * Math.PI) / 180)).toFixed(3);
  };
  draw();
  busy = gsap.to(turnState, {
    a: dir > 0 ? 180 : 0,
    duration: FLIP,
    ease: 'power2.inOut',
    onUpdate: draw,
    onComplete: () => {
      busy = null;
      lowShade.style.opacity = '0';
      topShade.style.opacity = '0';
      moving.style.removeProperty('opacity');
      if (dir > 0) {
        flip.remove();
      } else {
        sheets.appendChild(fresh);
        flip.remove();
        old.remove();
        place(fresh);
      }
      if (cal.contains(document.activeElement) && document.activeElement.classList.contains('date') === false && keys) focusDay();
    },
  });
}
prevBtn.addEventListener('click', () => turn(-1));
nextBtn.addEventListener('click', () => turn(1));

/* a swipe on the pad: up turns forward, down turns back (and the tap that ends it chooses nothing) */
let swipeFrom = null;
let swiped = 0;
pad.addEventListener('pointerdown', (e) => { if (e.pointerType !== 'mouse') swipeFrom = e.clientY; });
pad.addEventListener('pointerup', (e) => {
  if (swipeFrom === null) return;
  const dy = e.clientY - swipeFrom;
  swipeFrom = null;
  if (Math.abs(dy) < 40) return;
  swiped = performance.now();
  turn(dy < 0 ? 1 : -1);
});
pad.addEventListener('pointercancel', () => { swipeFrom = null; });

sheets.addEventListener('click', (e) => {
  const b = e.target.closest('.date');
  if (!b || !current.contains(b) || performance.now() - swiped < 400) return;
  focusDate = b.dataset.date;
  choose(b.dataset.date);
});

/* ---------------------------------------------------------------- the keyboard */
let focusDate = picked;
let keys = false;
cal.addEventListener('pointerdown', () => { keys = false; });
function roving() {
  const days = [...current.querySelectorAll('.date')];
  const want = days.find((b) => b.dataset.date === focusDate) || days.find((b) => b.dataset.date === picked) || days[0];
  days.forEach((b) => { b.tabIndex = b === want ? 0 : -1; });
}
function focusDay() {
  current.querySelector('.date[tabindex="0"]')?.focus();
}
sheets.addEventListener('keydown', (e) => {
  const b = e.target.closest('.date');
  if (!b) return;
  const d = dateOf(b.dataset.date);
  const col = (d.getDay() - WEEK_START + 7) % 7;
  const moves = {
    ArrowLeft: () => plus(d, -1),
    ArrowRight: () => plus(d, 1),
    ArrowUp: () => plus(d, -7),
    ArrowDown: () => plus(d, 7),
    Home: () => plus(d, -col),
    End: () => plus(d, 6 - col),
    PageUp: () => new Date(d.getFullYear(), d.getMonth() - 1, Math.min(d.getDate(), 28)),
    PageDown: () => new Date(d.getFullYear(), d.getMonth() + 1, Math.min(d.getDate(), 28)),
  };
  if (!moves[e.key]) return;
  e.preventDefault();
  keys = true;
  const to = moves[e.key]();
  focusDate = iso(to);
  const m = monthOf(to);
  if (m.getTime() !== shown.getTime()) {
    turn(m > shown ? 1 : -1);
    if (busy) busy.progress(1);
  }
  roving();
  focusDay();
});

/* ---------------------------------------------------------------- the wire binding, drawn for the pad's width */
function drawWire() {
  const w = wire.getBoundingClientRect().width;
  const loops = Math.max(8, Math.round(w / 24));
  let svg = '';
  for (let i = 0; i < loops; i++) {
    const x = ((i + 0.5) * w) / loops;
    svg += `<rect x="${(x - 5).toFixed(1)}" y="19" width="10" height="6" rx="2.5" fill="#1c1a17" opacity="0.85"/>`;
    for (const dx of [-2.2, 2.2]) {
      const xx = (x + dx).toFixed(1);
      svg += `<path d="M${xx} 23 C${xx} 2, ${(x + dx * 1.6).toFixed(1)} 2, ${(x + dx * 1.6).toFixed(1)} 12" fill="none" stroke="#9da1a8" stroke-width="2.6" stroke-linecap="round"/>`;
      svg += `<path d="M${xx} 21 C${xx} 4, ${(x + dx * 1.6).toFixed(1)} 4, ${(x + dx * 1.6).toFixed(1)} 11" fill="none" stroke="#e6e8ec" stroke-width="0.9" stroke-linecap="round"/>`;
    }
  }
  wire.innerHTML = svg;
}

/* ---------------------------------------------------------------- the pad arrives, and the marker circles a day */
const first = sheetEl(shown);
sheets.appendChild(first);
place(first);
drawWire();
addRing(first, false);
addEventListener('resize', () => {
  drawWire();
  const ink = current.querySelector('.sheet__ink');
  ink.innerHTML = '';
  addRing(current, false);
});
if (!REDUCED) {
  const ring = current.querySelector('.sheet__ink path');
  gsap.from(pad, { y: -40, rotationX: -12, transformPerspective: 1200, transformOrigin: '50% 0%', autoAlpha: 0, duration: 1.1, ease: 'power3.out' });
  gsap.from('.calendar__nav', { autoAlpha: 0, y: 12, duration: 0.7, ease: 'power3.out', delay: 0.3 });
  if (ring) gsap.fromTo(ring, { strokeDashoffset: ring.getTotalLength() }, { strokeDashoffset: 0, duration: INK, ease: 'power1.inOut', delay: 0.75 });
}
