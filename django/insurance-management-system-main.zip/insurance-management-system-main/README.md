# 🛡️ Insurance Management System

<div align="center">

![Python](https://img.shields.io/badge/Python-3.7%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Django](https://img.shields.io/badge/Django-3.0.5-092E20?style=for-the-badge&logo=django&logoColor=white)
![SQLite](https://img.shields.io/badge/SQLite-Database-003B57?style=for-the-badge&logo=sqlite&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-Active-brightgreen?style=for-the-badge)

A full-featured **Insurance Management Web Application** built with Django, enabling admins to manage insurance policies and customers to apply for and track their policies — all through a clean, intuitive interface.

</div>

---

## 📋 Table of Contents

- [Features](#-features)
- [Architecture](#-architecture)
- [Directory Structure](#-directory-structure)
- [Tech Stack](#-tech-stack)
- [Setup & Installation](#-setup--installation)
- [Environment Variables](#-environment-variables)
- [Usage](#-usage)
- [Disclaimer](#-disclaimer)

---

## ✨ Features

### 👨‍💼 Admin
| Feature | Description |
|---|---|
| Customer Management | View, update, and delete registered customers |
| Category Management | Add / edit / delete policy categories (Life, Health, Motor, Travel, etc.) |
| Policy Management | Create, update, and remove insurance policies |
| Policy Holder Review | Approve or reject customer policy applications |
| Q&A Panel | Respond to questions submitted by customers |
| Dashboard | Overview of total users, policies, categories, and pending requests |

### 👤 Customer
| Feature | Description |
|---|---|
| Self Registration | Sign up without admin approval |
| Policy Browser | View all available policies with full details |
| Policy Application | Apply for any policy; applications enter a *Pending* state |
| Application History | Track approval/rejection status of applied policies |
| Q&A System | Submit questions to the admin and view responses |

---

## 🏗️ Architecture

```
Browser
   │
   ▼
Django URL Router (insurancemanagement/urls.py + customer/urls.py)
   │
   ├── insurance app   → Admin-facing views, policy & category CRUD
   │       ├── models.py     (Category, Policy, PolicyRecord, Question, Contact)
   │       ├── views.py      (Admin dashboard, approvals, Q&A)
   │       └── forms.py      (Category, Policy, Question, Contact forms)
   │
   └── customer app    → Customer-facing views, registration, profile
           ├── models.py     (Customer)
           ├── views.py      (Registration, dashboard, policy apply)
           └── forms.py      (CustomerUser, Customer forms)

Shared:
   ├── templates/      (HTML templates for both apps)
   ├── static/         (CSS, JS, images)
   └── db.sqlite3      (SQLite database — local dev only)
```

---

## 📁 Directory Structure

```
insurance-management-system/
│
├── insurancemanagement/        # Django project config
│   ├── settings.py             # Project settings (uses .env)
│   ├── urls.py                 # Root URL configuration
│   ├── wsgi.py                 # WSGI entry point
│   └── asgi.py                 # ASGI entry point
│
├── insurance/                  # Core admin app
│   ├── models.py               # Category, Policy, PolicyRecord, Question
│   ├── views.py                # Admin views & logic
│   ├── forms.py                # Admin forms
│   ├── admin.py                # Django admin registrations
│   └── migrations/             # Database migrations
│
├── customer/                   # Customer-facing app
│   ├── models.py               # Customer model
│   ├── views.py                # Customer views & logic
│   ├── forms.py                # Customer forms
│   └── migrations/             # Database migrations
│
├── templates/                  # HTML templates
│   ├── insurance/              # Admin & shared templates
│   └── customer/               # Customer-specific templates
│
├── static/                     # Static assets (CSS, JS, images)
│
├── manage.py                   # Django management utility
├── requirements.txt            # Python dependencies
├── .env.example                # Environment variable template
└── .gitignore                  # Git ignore rules
```

---

## 🛠️ Tech Stack

- **Backend:** Python 3.7+, Django 3.0.5
- **Frontend:** HTML5, CSS3, Bootstrap, Django Templates
- **Database:** SQLite (development) — easily swappable to PostgreSQL/MySQL
- **Auth:** Django's built-in authentication system with group-based permissions
- **Email:** SMTP via Gmail (configurable)
- **Config:** `python-decouple` for environment-based configuration

---

## ⚡ Setup & Installation

### Prerequisites
- Python 3.7 or higher (ensure it is added to PATH during installation)
- `pip` package manager
- Git

### 1. Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/insurance-management-system.git
cd insurance-management-system
```

### 2. Create a Virtual Environment
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS / Linux
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure Environment Variables
```bash
# Copy the example file and fill in your values
cp .env.example .env
```
Edit `.env` with your actual values (see [Environment Variables](#-environment-variables) below).

### 5. Apply Database Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 6. Create an Admin Superuser
```bash
python manage.py createsuperuser
```

### 7. Run the Development Server
```bash
python manage.py runserver
```

### 8. Open in Browser
```
http://127.0.0.1:8000/
```

---

## 🔐 Environment Variables

Copy `.env.example` to `.env` and set the following:

| Variable | Description | Example |
|---|---|---|
| `SECRET_KEY` | Django secret key — generate a unique one | `your-50-char-secret-key` |
| `DEBUG` | Enable debug mode (`True` for dev, `False` for prod) | `True` |
| `ALLOWED_HOSTS` | Comma-separated allowed hostnames | `127.0.0.1,localhost` |
| `EMAIL_HOST_USER` | Gmail address used to send emails | `youremail@gmail.com` |
| `EMAIL_HOST_PASSWORD` | Gmail app password (not your login password) | `xxxx xxxx xxxx xxxx` |
| `EMAIL_RECEIVING_USER` | Email address that receives contact messages | `admin@example.com` |

> **Note:** For Gmail, generate an **App Password** from your Google Account → Security → 2-Step Verification → App Passwords. Never use your main password.

---

## 🚀 Usage

| URL | Description |
|---|---|
| `/` | Home / landing page |
| `/adminlogin` | Admin login page |
| `/admin-dashboard` | Admin control panel |
| `/customer/customerlogin` | Customer login page |
| `/customer/customersignup` | Customer registration |
| `/aboutus` | About page |
| `/contactus` | Contact form |

---

## ⚠️ Disclaimer

This project is built for **educational and demonstration purposes only**. It is not intended for production use without significant security hardening (e.g., HTTPS, proper secret management, database hardening).

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
